#include <stdio.h>
#include<stdlib.h>
#include"abb.h"

/* Cria uma arvore vazia*/
Arvore* cria_arvore(){
  Arvore* nova = (Arvore*)malloc(sizeof(Arvore)); // declara uma nova arvore, alocando a memoria dinamicamente para ela com base na estrutura arvore.
  nova->raiz = NULL;// aponta o ponteiro da estrutura Raiz para nulo. 

  return nova;
}

void insere_no(No* pai, No* n){
  if(pai != NULL){
      //subarvore esquerda
      if(n->valor < pai->valor){
        if(pai->esq==NULL){
          pai->esq = n;

        }
        else{
          insere_no(pai->esq, n);
        }
      }
      //subarvore direita
      else if (n->valor > pai->valor){
        if(pai->dir==NULL){
          pai->dir = n;

        }
        else{
          insere_no(pai->dir, n);
      }
  }
  }
  return;
}

/* Insere elemento no nó da arvore*/

void insere(Arvore* A, int v) {
  No* novo_no = (No*) malloc(sizeof(No)); //declara a variavel novo no para receber alocação de memoria dinamicamente
  novo_no->valor = v;
  // apontar nos da direita e esquerda como null para evitar qualquer tipo de endereçamento incorreto.
  novo_no->esq = NULL;
  novo_no->dir = NULL;
  // Se for vazia o nóó criado seráá o unico da arvore.
  if (A-> raiz == NULL){
    A->raiz = novo_no; // unico nóó da arvore.
  }
  else{
    insere_no(A->raiz, novo_no);
  }
  return;
}

// impressãão inordem ((esquerda-raiz-direita )
void imprime_inordem(No* n) {
  if(n!=NULL){
    imprime_inordem(n->esq);
    printf("%d ", n->valor);
    imprime_inordem(n->dir);}
  return;
}

void inordem(Arvore* A){
  imprime_inordem(A->raiz);
  return;
}
