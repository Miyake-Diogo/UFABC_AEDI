#include <math.h> 
#include <stdio.h> 

int main() 
{ 
    int n; 
    scanf("%d", &n);
    printf("%d\n", (int)log2(n)); 
    return 0; 
} 