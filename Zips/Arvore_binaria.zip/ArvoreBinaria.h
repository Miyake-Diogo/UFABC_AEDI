typedef struct No* ArvBin;

ArvBin* cria_ArvBin();

void libera_ArvBin(ArvBin* raiz);

int estaVazia_ArvBin(ArvBin* raiz);

int altura_Arvbin(ArvBin* raiz);

int totalNo_ArvBin(ArvBin* raiz);

void preOrdem_ArvBin(ArvBin* raiz);

void emOrdem_ArvBin(ArvBin* raiz)

void posOrdem_ArvBin(ArvBin* raiz)