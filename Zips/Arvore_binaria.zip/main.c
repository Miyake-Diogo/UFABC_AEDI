#include <stdio.h>
#include <stdlib.h>
#include "ArvoreBinaria.h"
ArvBin* raiz;


int main(void) {

  ArvBin* raiz = cria_ArvBin();
  libera_ArvBin(raiz);
  int x = estaVazia_ArvBin(raiz);
  //if(estaVazia_ArvBin(raiz))
  int y = altura_Arvbin(raiz);
  int z = totalNo_ArvBin(raiz);
  preOrdem_ArvBin(raiz);
  emOrdem_ArvBin(raiz);
  posOrdem_ArvBin(raiz);
  return 0;
}